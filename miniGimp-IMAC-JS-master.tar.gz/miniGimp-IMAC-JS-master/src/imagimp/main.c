#include "Imagimp.h"

int main(int argc, char* argv[]) {
    Imagimp_launch(argc,argv);
    return 0;
}
